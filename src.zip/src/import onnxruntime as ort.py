import onnxruntime as ort
print(ort.__file__)