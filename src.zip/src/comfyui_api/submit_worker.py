# src/submit_worker.py
import json
import os
import shutil
from PyQt6.QtCore import QThread, pyqtSignal
import time as pyt
import traceback
import requests
import websocket   # 新增
import threading
class ComfySubmitWorker(QThread):
    status = pyqtSignal(str)           # 文本状态
    progress = pyqtSignal(int, int)    # 已完成, 总数
    finished_ok = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, client, tasks,tmp_output_dir,wait_timeout=180, wait_interval=2, parent=None):
        super().__init__(parent)
        self.client = client
        self.tasks = tasks
        self.client_tmp_output_dir = tmp_output_dir # ComfyUI 输出目录
        self.real_output_dir = None # 最终想要存放的目录
        self.tasks_info = None
        self.wait_timeout = wait_timeout
        self.wait_interval = wait_interval
        self.ws_thread = None
        self.prompt_ids = set()   # 存储提交过的 prompt_id
    def set_output_dir(self, path):
        """设置最终输出目录"""
        self.real_output_dir = path
        if not os.path.exists(path):
            os.makedirs(path, exist_ok=True)
    def set_tasks_info(self, info: dict):
        """设置任务信息"""
        self.tasks_info = info
    def run(self):
        try:
            # 1) 健康检查
            self.status.emit("检查端口连通性...")
            if not self.client.is_port_open():
                raise RuntimeError("ComfyUI 端口无法访问")

            self.status.emit("检查服务状态...")
            if not self.client.is_comfy_alive():
                raise RuntimeError("ComfyUI 未响应 /system_stats")

            total = len(self.tasks)
            done = 0

             # 2) 启动 WebSocket 监听
            self._start_ws_listener()

            total = len(self.tasks)
            done = 0

            # 3) 提交任务
            for t in self.tasks:
                rel_input = t.get("rel_input")
                if rel_input:
                    self.status.emit(f"等待文件同步到服务器: {rel_input}")
                    self._wait_input(rel_input)

                self.status.emit("提交任务到 /prompt ...")
                prompt_id = self.client.submit(t["payload"])
                t["prompt_id"] = prompt_id
                self.prompt_ids.add(prompt_id)  # 保存 id 供 WebSocket 匹配
                self.status.emit(f"任务已提交，prompt_id: {prompt_id}")

                done += 1
                self.progress.emit(done, total)

            self.status.emit("全部任务已提交，等待 WebSocket 推送任务完成事件。")
            # 注意：这里不 emit finished_ok，因为我们要靠 WebSocket 事件判断完成

        except Exception as e:
            tb = traceback.format_exc(limit=5)
            self.failed.emit(f"{e}\n{tb}")

    def _wait_input(self, rel_input: str):
        # 轻量轮询，避免卡 UI（在子线程里不会卡主界面）
        if "/" not in rel_input:
            raise ValueError(f"rel_input 格式应为 'subfolder/filename': {rel_input}")
        subfolder, filename = rel_input.split("/", 1)

        deadline = pyt.time() + self.wait_timeout
        last_status = None
        while pyt.time() < deadline:
            try:
                r = self.client.session.get(
                    f"{self.client.base_url}/view",
                    params={"filename": filename, "subfolder": subfolder, "type": "input"},
                    timeout=5
                )
                last_status = r.status_code
                if r.status_code == 200:
                    return
            except Exception as ex:
                last_status = str(ex)

            self.status.emit(f"等待中（最后状态: {last_status}）...")
            self.msleep(int(self.wait_interval * 1000))

        raise TimeoutError(f"等待文件可读超时: {rel_input}，最后状态: {last_status}")
    def _on_ws_message(self, ws, message):
        try:
            data = json.loads(message)
            ptype = data.get("type")
            print('ptype: ', ptype)
            pdata = data.get("data", {})
            if ptype == 'progress':
                print('pdata: ', pdata)
            pid = pdata.get("prompt_id")
            # 只处理我们自己提交的任务
            if pid and pid in self.prompt_ids:
                if ptype == "executed":
                    self.status.emit(f"[{pid}] 节点执行完成: {pdata.get('node_id')}")
            if ptype == "progress":
                self._handle_progress_update(pid, pdata)
            if ptype == "execution_success":
                self.status.emit(f"[{pid}] 任务执行成功")
                print('检测到 execution_success')
        except Exception as e:
            self.status.emit(f"WebSocket 消息解析失败: {e}")

    def _on_ws_error(self, ws, error):
        self.status.emit(f"WebSocket 错误: {error}")

    def _on_ws_close(self, ws, code, msg):
        self.status.emit("WebSocket 连接已关闭")

    def _start_ws_listener(self):
        """独立线程运行 WebSocket 监听"""
        ws_url = f"ws://{self.client.host}:{self.client.port}/ws"
        self.status.emit(f"连接 WebSocket: {ws_url}")

        def run_ws():
            self.ws = websocket.WebSocketApp(
                ws_url,
                on_message=self._on_ws_message,
                on_error=self._on_ws_error,
                on_close=self._on_ws_close
            )
            self.ws.run_forever()

        self.ws_thread = threading.Thread(target=run_ws, daemon=True)
        self.ws_thread.start()
    def _handle_progress_update(self, pid: str, pdata: dict):
        """处理 WebSocket 推送的任务进度"""
        value = pdata.get("value", 0)
        maxv = pdata.get("max", 1)

        # 更新状态文本
        self.status.emit(f"[{pid}] 进度: {value}/{maxv}")

        # 更新进度条
        if maxv > 0:
            self.progress.emit(value, maxv)

        # 任务完成时
        if value >= maxv:
            print('renwu wancheng ')
            self._handle_task_complete(pid)
    def _handle_task_complete(self, pid: str):
        """任务完成后处理：获取输出文件并搬运改名"""
        try:
            self.status.emit(f"[{pid}] 等待 history 写入...")
            max_wait = 10
            start_time = pyt.time()
            hist = {}
            while pyt.time() - start_time < max_wait:
                r = requests.get(f"{self.client.base_url}/history/{pid}", timeout=5).json()
                if pid in r and "outputs" in r[pid] and r[pid]["outputs"]:
                    hist = r
                    break
                self.msleep(500)  # 0.5 秒
            else:
                raise TimeoutError(f"history/{pid} 超时未写入")

            outputs = hist[pid]["outputs"]
            tmp_output_file = self.get_tmp_output_path(outputs)
            self.move_rename_output_file(tmp_output_file,self.real_output_dir)

            self.status.emit(f"[{pid}] 任务处理完成")
        except Exception as e:
            self.status.emit(f"[{pid}] 获取结果或搬运文件失败: {e}")
        self.ws.close()  # 任务完成后关闭 WebSocket 连接
    
    def get_tmp_output_path(self,outputs_node):
        """安全地获取临时输出文件路径"""
        if not outputs_node or not isinstance(outputs_node, dict):
            print("[WARN] outputs_node 为空或不是字典")
            return None

        for node_id, out in outputs_node.items():
            if not isinstance(out, dict):
                continue
            images = out.get("images")
            if not images or not isinstance(images, list):
                continue

            for img in images:
                if not isinstance(img, dict):
                    continue
                if img.get("type") == "output" and "filename" in img:
                    src_file = os.path.join(self.client_tmp_output_dir, img["filename"])
                    if os.path.exists(src_file):
                        return src_file
                    else:
                        print(f"[WARN] 文件不存在: {src_file}")

        print("[WARN] 没有找到有效的输出文件")
        return None
    def move_rename_output_file(self, src_path: str, dst_dir: str, new_name: str):
        """搬运并改名输出文件"""
        try:
            if not os.path.isfile(src_path):
                raise FileNotFoundError(f"源文件不存在: {src_path}")
            os.makedirs(dst_dir, exist_ok=True)
            dst_path = os.path.join(dst_dir, new_name)
            shutil.move(src_path, dst_path)
            self.status.emit(f"已搬运到: {dst_path}")
        except Exception as e:
            self.status.emit(f"搬运文件失败: {e}")