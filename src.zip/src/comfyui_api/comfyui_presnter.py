# src/comfyui/presenter.py
from PyQt6.QtCore import QObject
from .workflow_manager import WorkflowManager
from .submit_worker import ComfySubmitWorker
from .api_client import ComfyApiClient

class ComfyUIPresenter(QObject):
    def __init__(self, model, view):
        super().__init__()
        self.view = view   # ComfyUISection
        self.model = model # 主 Model（包含文件列表等）

        # 连接 UI 信号
        self.view.submit_comfy_task.connect(self.on_submit_task)

        # API 客户端
        self.client = ComfyApiClient()

    def on_submit_task(self, info: dict):
        """UI 点击提交按钮时调用"""
        try:
            # 1) 构造任务
            wf_manager = WorkflowManager(self.model, info)
            tasks = wf_manager.create_comfy_tasks()

            # 2) 启动 Worker
            worker = ComfySubmitWorker(
                client=self.client,
                tasks=tasks,
                tmp_output_dir=str(info["temp_img_output_dir"])
            )
            worker.set_output_dir("final_output")  # TODO: 根据你的实际输出目录来
            worker.start()

            # 3) 绑定 Worker 信号到 View
            worker.status.connect(self.view.update_status)
            worker.progress.connect(self.view.update_progress)
            worker.failed.connect(self.view.show_error)
            worker.finished_ok.connect(lambda: self.view.show_message("任务完成"))

        except Exception as e:
            self.view.show_error(str(e))
